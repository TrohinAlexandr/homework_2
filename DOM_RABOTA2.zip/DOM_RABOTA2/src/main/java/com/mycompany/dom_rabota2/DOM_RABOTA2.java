/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dom_rabota2;

/**
 *
 * @author User
 */

import java.util.Scanner;

public class DOM_RABOTA2 {
    public static void main(String[] args) {
        String name, habitat, fruit, petalColor, berry;
        double lifeTimeInYears, heightInMeters;
        boolean hasSpikes;
        System.out.println("Трохин Александр Андреевич");
        System.out.println("Группа РИБО-01-21, Вариант 4");
        System.out.println();
        System.out.println("Выберите тип растения (Введите число):");
        System.out.println("1 - Дерево");
        System.out.println("2 - Цветок");
        System.out.println("3 - Куст");
        int a = Integer.parseInt(scan());
        switch (a) {
            case 1 -> {
                System.out.println("Выберите тип дерева (введите число):");
                System.out.println("1 - Плодоносное");
                System.out.println("2 - Хвойное");
                a = Integer.parseInt(scan());
                switch (a) {
                    case 1 -> {
                        System.out.println("Введите название дерева:");
                        name = scan();
                        System.out.println("Укажите среднюю продолжительность жизни дерева (в годах):");
                        lifeTimeInYears = Double.parseDouble(scan());
                        System.out.println("Укажите среднюю высоту дерева (в метрах):");
                        heightInMeters = Double.parseDouble(scan());
                        System.out.println("Укажите место обитания:");
                        habitat = scan();
                        System.out.println("Укажите, какой фрукт растет на дереве:");
                        fruit = scan();
                        System.out.println("Объект успешно создан!");
                        System.out.println();
                        System.out.println(new FruitTree(name, lifeTimeInYears, heightInMeters, habitat, fruit));
                    }
                    case 2 -> {
                        System.out.println("Введите название дерева:");
                        name = scan();
                        System.out.println("Укажите среднюю продолжительность жизни дерева (в годах):");
                        lifeTimeInYears = Double.parseDouble(scan());
                        System.out.println("Укажите среднюю высоту дерева (в метрах):");
                        heightInMeters = Double.parseDouble(scan());
                        System.out.println("Укажите место обитания:");
                        habitat = scan();
                        System.out.println("Объект успешно создан!");
                        System.out.println();
                        System.out.println(new ConiferousTree(name, lifeTimeInYears, heightInMeters, habitat));
                    }
                    default -> System.out.println("Ошибка! Нужно ввести целое число от 1 до 2");
                }
            }


            case 2 -> {
                System.out.println("Введите название цветка:");
                name = scan();
                System.out.println("Укажите среднюю продолжительность жизни цветка (в годах):");
                lifeTimeInYears = Double.parseDouble(scan());
                System.out.println("Укажите среднюю высоту цветка (в метрах):");
                heightInMeters = Double.parseDouble(scan());
                System.out.println("Есть ли у вашего цветка шипы? (Введите число)");
                System.out.println("1 - Да");
                System.out.println("2 - Нет");
                a = Integer.parseInt(scan());
                switch (a) {
                    case 1 -> hasSpikes = true;
                    case 2 -> hasSpikes = false;
                    default -> {
                        System.out.println("Ошибка! Нужно ввести число от 1 до 2");
                        return;
                    }
                }
                System.out.println("Укажите цвет лепестков:");
                petalColor = scan();
                System.out.println("Объект успешно создан!");
                System.out.println(new Flower(name, lifeTimeInYears, heightInMeters, hasSpikes, petalColor));
            }


            case 3 -> {
                System.out.println("Введите название куста:");
                name = scan();
                System.out.println("Укажите среднюю продолжительность жизни куста (в годах):");
                lifeTimeInYears = Double.parseDouble(scan());
                System.out.println("Укажите среднюю высоту куста (в метрах):");
                heightInMeters = Double.parseDouble(scan());
                System.out.println("Есть ли у вашего куста ягоды? (Введите число)");
                System.out.println("1 - Да");
                System.out.println("2 - Нет");
                a = Integer.parseInt(scan());
                if (a == 1) {
                    System.out.println("Какая ягода растет на вашем дереве?:");
                    berry = scan();
                    System.out.println("Объект успешно создан!");
                    System.out.println();
                    System.out.println(new Bush(name, lifeTimeInYears, heightInMeters, true, berry));
                } else if (a == 2) {
                    System.out.println("Объект успешно создан!");
                    System.out.println();
                    System.out.println(new Bush(name, lifeTimeInYears, heightInMeters, false));
                } else {
                    System.out.println("Ошибка! Нужно ввести число от 1 до 2");
                }
            }
            default -> System.out.println("Ошибка! Нужно ввести число от 1 до 3");
        }

    }

    public static String scan() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
}