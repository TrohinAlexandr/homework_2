package com.mycompany.dom_rabota2;

public class Flower extends Plant {
    private boolean hasSpikes;
    private String petalColor;

    public Flower(String name, double lifeTimeInYears, double height, boolean hasSpikes, String petalColor) {
        super(name, lifeTimeInYears, height);
        this.hasSpikes = hasSpikes;
        this.petalColor = petalColor;
    }

    public void transplant() {
        System.out.println("Пересаживаем " + getName());
    }

    @Override
    public String toString() {
        String spikes;
        if (hasSpikes) {
            spikes = "да";
        } else {
            spikes = "нет";
        }
        return "Цветок " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров, " +
                "Имеет шипы: " + spikes + ", Цвет лепестков: " + petalColor;
    }

    public boolean isHasSpikes() {
        return hasSpikes;
    }

    public void setHasSpikes(boolean hasSpikes) {
        this.hasSpikes = hasSpikes;
    }

    public String getPetalColor() {
        return petalColor;
    }

    public void setPetalColor(String petalColor) {
        this.petalColor = petalColor;
    }
}
