package com.mycompany.dom_rabota2;

public class ConiferousTree extends Tree {

    public ConiferousTree(String name, double lifeTimeInYears, double height, String habitat) {
        super(name, lifeTimeInYears, height, habitat);
    }

    public void collectCones() {
        System.out.println("Собираем шишки с хвойного дерева " + getName());
    }

    @Override
    public String toString() {
        return "Хвойное дерево " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров, " +
                "Среда обитания: " + getHabitat();
    }
}
