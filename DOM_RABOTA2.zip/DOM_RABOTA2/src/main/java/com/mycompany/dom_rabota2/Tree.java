package com.mycompany.dom_rabota2;


import com.mycompany.dom_rabota2.Plant;

public class Tree extends Plant {
    private String habitat;

    public Tree(String name, double lifeTimeInYears, double height, String habitat) {
        super(name, lifeTimeInYears, height);
        this.habitat = habitat;

    }

    public void cutDown() {
        System.out.println("Срубаем дерево " + getName());
    }

    @Override
    public String toString() {
        return "Дерево " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров, " +
                "Среда обитания: " + habitat;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
}
