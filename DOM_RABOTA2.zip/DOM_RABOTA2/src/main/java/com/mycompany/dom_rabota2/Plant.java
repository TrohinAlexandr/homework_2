package com.mycompany.dom_rabota2;

public class Plant {
    private String name;
    private double lifeTimeInYears;
    private double heightInMeters;

    public Plant(String name, double lifeTimeInYears, double height) {
        this.name = name;
        if (lifeTimeInYears <= 0) {
            this.lifeTimeInYears = 1;
        } else {
            this.lifeTimeInYears = lifeTimeInYears;
        }
        if (height <= 0) {
            this.heightInMeters = 1;
        } else {
            this.heightInMeters = height;
        }
    }

    public void water() {
        System.out.println("Поливаем " + name + "...  Готово!");
    }

    public void fertilize() {
        System.out.println("Удобряем " + name + "...  Готово!");
    }

    @Override
    public String toString() {
        return "Растение " + getName() + ", Средняя продолжительность: " + lifeTimeInYears + " лет, Средний рост: " + heightInMeters + " метров";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLifeTimeInYears() {
        return lifeTimeInYears;
    }

    public void setLifeTimeInYears(double lifeTimeInYears) {
        if (lifeTimeInYears <= 0) {
            this.lifeTimeInYears = 1;
        } else {
            this.lifeTimeInYears = lifeTimeInYears;
        }
    }

    public double getHeight() {
        return heightInMeters;
    }

    public void setHeight(double height) {
        if (height <= 0) {
            this.heightInMeters = 1;
        } else {
            this.heightInMeters = height;
        }
    }
}
