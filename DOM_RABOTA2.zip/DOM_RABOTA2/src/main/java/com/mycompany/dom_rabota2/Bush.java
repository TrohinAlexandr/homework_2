package com.mycompany.dom_rabota2;

public class Bush extends Plant {
    private boolean hasBerries;
    private String berry;

    public Bush(String name, double lifeTimeInYears, double height, boolean hasBerries, String berry) {
        super(name, lifeTimeInYears, height);
        this.hasBerries = hasBerries;
        this.berry = berry;
    }

    public Bush(String name, double lifeTimeInYears, double height, boolean hasBerries) {
        super(name, lifeTimeInYears, height);
        this.hasBerries = hasBerries;
    }

    public void collectBerries() {
        if (hasBerries) {
            System.out.println("Собираем " + berry + " с " + getName());
        } else {
            System.out.println("Куст " + getName() + " не имеет ягод.");
        }
    }

    @Override
    public String toString() {
        String str;
        if (hasBerries) {
            str = "Куст " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров, Ягода: " + berry;
        } else {
            str = "Куст " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров";
        }
        return str;
    }

    public boolean isHasBerries() {
        return hasBerries;
    }

    public void setHasBerries(boolean hasBerries) {
        this.hasBerries = hasBerries;
    }

    public String getBerry() {
        return berry;
    }

    public void setBerry(String berry) {
        this.berry = berry;
    }
}
