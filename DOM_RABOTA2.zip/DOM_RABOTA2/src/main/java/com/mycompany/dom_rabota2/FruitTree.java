package com.mycompany.dom_rabota2;

public class FruitTree extends Tree {
    private String fruit;

    public FruitTree(String name, double lifeTimeInYears, double height, String habitat, String fruit) {
        super(name, lifeTimeInYears, height, habitat);
        this.fruit = fruit;
    }

    public void collectFruit() {
        System.out.println("Собираем " + fruit + " с дерева " + getName());
    }

    @Override
    public String toString() {
        return "Дерево " + getName() + ", Средняя продолжительность: " + getLifeTimeInYears() + " лет, Средний рост: " + getHeight() + " метров, " +
                "Среда обитания: " + getHabitat() + ", Фрукт: " + fruit;
    }

    public String getFruit() {
        return fruit;
    }

    public void setFruit(String fruit) {
        this.fruit = fruit;
    }
}
